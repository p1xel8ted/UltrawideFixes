using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.NetCode;
using Unity.Transforms;

[UpdateInWorld(TargetWorld.Client)]
[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial class MoveLocalPlayerSystem : PugSimulationSystemBase
{
    protected override void OnUpdate()
    {
        var deltaTime = Time.DeltaTime;
        Entities.WithAll<PlayerMovementForceCD>().WithChangeFilter<PlayerMovementForceCD>().ForEach(
            (Entity entity, ref Translation translation) =>
            {
                translation.Value.x += deltaTime;
            }).Schedule();
        
        base.OnUpdate();
    }
}

[UpdateInWorld(TargetWorld.Server)]
[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial class MoveCowsAwayFromPlayerSystem : PugSimulationSystemBase
{
    protected override void OnUpdate()
    {
        // No need to dispose World allocator
        var playerPositions = new NativeList<float3>(World.UpdateAllocator.ToAllocator);

        Entities.WithAll<PlayerGhost>().ForEach((in Translation translation) =>
        {
            playerPositions.Add(translation.Value);
        }).Schedule();
        
        var deltaTime = Time.DeltaTime;
        var distanceToMoveSq = 5 * 5;
        // Filter on cattle just to avoid looping through everything
        Entities.WithAll<CattleCD>().ForEach((ref Translation translation, in ObjectDataCD objectData) =>
            {
                if (objectData.objectID != ObjectID.Cow)
                {
                    return;
                }
                
                foreach (var playerPos in playerPositions)
                {
                    if (math.distancesq(translation.Value, playerPos) < distanceToMoveSq)
                    {
                        var dir = math.normalizesafe(translation.Value - playerPos);
                        translation.Value += dir * deltaTime;
                    }
                }
            }).Schedule();
        
        base.OnUpdate();
    }
}